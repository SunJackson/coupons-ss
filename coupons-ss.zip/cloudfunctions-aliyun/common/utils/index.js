exports.APPID = 'wx9472d5ad54e879ed';  //这里是我的appid，需要改成你自己的
exports.SECREAT = '7fefd*************65778a';   //密钥也要改成你自己的
